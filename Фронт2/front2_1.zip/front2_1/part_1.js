function hide(a){
    document.querySelector('#'+a).style.display = "none";
}

function showImg(a) {
    document.querySelector('#imgMain').src = a+".jpg";
}
function show(a){
    document.querySelector('#'+a).style.display = "block";
}
